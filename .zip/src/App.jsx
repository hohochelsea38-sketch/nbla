import React from "react" ;
import Navbar from "./sections/navbar";
import Hero  from "./sections/hero";
import About from "./sections/About";
import Skills from "./sections/skills";
import Contact from "./sections/Contact";
import Footer from "./sections/footer";
const app = () => {
  return <div className="container mx-auto max-w-7xl ">
    <Navbar/>
    <Hero/>
    <About />
    <Skills />
    <Contact />
    < Footer />
  </div>;

};

export default app;